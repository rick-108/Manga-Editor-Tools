import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, pagesTable } from "@workspace/db";
import { RemoteImportBody, RemotePreviewBody } from "@workspace/api-zod";
import { requirePublisher } from "../middlewares/publisher";
import { storeRemoteImage, usingImgbb } from "../lib/storage";
import axios from "axios";
import * as cheerio from "cheerio";

function getOrigin(url: string): string {
  try { return new URL(url).origin; } catch { return ""; }
}

function getHostname(url: string): string {
  try { return new URL(url).hostname; } catch { return ""; }
}

function buildHeaders(url: string, extraHeaders: Record<string, string> = {}) {
  const origin = getOrigin(url);
  return {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "Referer": origin + "/",
    "Origin": origin,
    "sec-ch-ua": '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "none",
    "sec-fetch-user": "?1",
    "Upgrade-Insecure-Requests": "1",
    "Cache-Control": "max-age=0",
    "Connection": "keep-alive",
    ...extraHeaders,
  };
}

function toAbs(src: string, base: string): string | null {
  if (!src || src.startsWith("data:") || src.length < 5) return null;
  src = src.trim().replace(/\\\//g, "/");
  if (src.startsWith("//")) return "https:" + src;
  if (src.startsWith("http")) return src;
  try { return new URL(src, base).href; } catch { return null; }
}

function dedupe(arr: string[]): string[] { return [...new Set(arr)]; }

const IMG_EXT = /\.(jpe?g|png|webp|gif|avif|bmp)(\?[^"'<>\s]*)?$/i;

const UI_BLACKLIST = /logo|icon|avatar|banner|sprite|placeholder|loading|spinner|blank|ad[_\-]|\/ads?\/|noimage|default\.(png|jpe?g)|thumbnail[_\-]small|favicon|emoji|button|social|share|arrow|close|menu|header|footer|navbar|sidebar/i;

function isMangaPage(url: string): boolean {
  if (!url || !url.startsWith("http")) return false;
  if (UI_BLACKLIST.test(url)) return false;
  return true;
}

// ─────────────────────────────────────────────
// STRATEGY HELPERS
// ─────────────────────────────────────────────

function extractTsReader(html: string, base: string): string[] {
  const urls: string[] = [];
  const rx = /ts_reader\.run\s*\(\s*(\{[\s\S]*?\})\s*\)/;
  const m = html.match(rx);
  if (!m) return urls;
  try {
    const obj = JSON.parse(m[1]);
    const sources: Array<{ images?: string[] }> = obj.sources ?? obj.source ?? [];
    for (const src of sources) {
      for (const img of src.images ?? []) {
        const abs = toAbs(img, base);
        if (abs && isMangaPage(abs)) urls.push(abs);
      }
    }
  } catch { }
  return urls;
}

function extractFromJsonBlobs(scripts: string[], base: string): string[] {
  const urls: string[] = [];
  for (const script of scripts) {
    const rx = /"(https?:\/\/[^"\\]{8,600})"|'(https?:\/\/[^'\\]{8,600})'/g;
    let m: RegExpExecArray | null;
    while ((m = rx.exec(script)) !== null) {
      const raw = m[1] || m[2];
      if (IMG_EXT.test(raw) && isMangaPage(raw)) {
        const abs = toAbs(raw, base);
        if (abs) urls.push(abs);
      }
    }
  }
  return urls;
}

function extractJsArrays(scripts: string[], base: string): string[] {
  const urls: string[] = [];
  const varPatterns: RegExp[] = [
    /sources\s*:\s*\[[\s\S]*?images\s*:\s*(\[[\s\S]*?\])/g,
    /(?:var|let|const)\s+(?:\w*[Pp]age\w*|\w*[Ii]mage\w*|\w*[Cc]hapter\w*)\s*=\s*(\[[^\]]{8,}\])/g,
    /window\s*\.\s*\w+\s*=\s*(\[[\s\S]{8,500}?\])/g,
    /"(?:images|pages|imgs|chapter_images|chapterImages|page_images)"\s*:\s*(\[[^\]]{8,}\])/g,
    /\b\w*(?:[Ii]mage|[Pp]age|[Pp]ict)\w*\s*=\s*(\[[\s\S]{8,500}?\])/g,
  ];

  for (const script of scripts) {
    for (const pat of varPatterns) {
      const rx = new RegExp(pat.source, pat.flags);
      let m: RegExpExecArray | null;
      while ((m = rx.exec(script)) !== null) {
        const captured = m[1];
        const inner = /"([^"\\]{8,500})"|'([^'\\]{8,500})'/g;
        let im: RegExpExecArray | null;
        while ((im = inner.exec(captured)) !== null) {
          const raw = im[1] || im[2];
          const abs = toAbs(raw, base);
          if (abs && isMangaPage(abs)) urls.push(abs);
        }
      }
    }
  }
  return urls;
}

/**
 * Strategy F – Astro nanostores / SolidJS / Vue serialized JSON in the page.
 * Looks for patterns like [0,"https://..."] or {"url":"https://..."} in inline data blobs.
 */
function extractAstroNanostores(html: string, base: string): string[] {
  const urls: string[] = [];
  // Match Astro/nanostores serialized arrays: [0,"https://...jpg"]
  const rx = /\[0\s*,\s*"(https?:\/\/[^"]{10,600})"/g;
  let m: RegExpExecArray | null;
  while ((m = rx.exec(html)) !== null) {
    const raw = m[1];
    if (IMG_EXT.test(raw) && isMangaPage(raw)) {
      const abs = toAbs(raw, base);
      if (abs) urls.push(abs);
    }
  }
  return urls;
}

/**
 * Strategy G – azorafly / _vcomics-style Astro sites.
 * Extracts chapterId from the serialized nanostores JSON, then calls the chapter API.
 */
async function extractVcomicsApi(html: string, base: string): Promise<string[]> {
  const urls: string[] = [];
  try {
    // Look for chapterId in Astro nanostores: "chapterId":[0,12345]
    const chapterIdMatch = html.match(/"chapterId"\s*:\s*\[\s*0\s*,\s*(\d+)\s*\]/);
    if (!chapterIdMatch) return urls;
    const chapterId = chapterIdMatch[1];
    const origin = getOrigin(base);

    // Try common API patterns for _vcomics-based Astro sites
    const endpoints = [
      `${origin}/api/chapters/${chapterId}/pages`,
      `${origin}/api/chapter/${chapterId}/pages`,
      `${origin}/api/chapter-pages/${chapterId}`,
      `${origin}/_vcomics/chapter/${chapterId}/pages`,
    ];

    for (const endpoint of endpoints) {
      try {
        const res = await axios.get(endpoint, {
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept": "application/json",
            "Referer": base,
          },
          timeout: 10000,
        });
        if (res.status === 200 && typeof res.data === "object") {
          const data = res.data;
          // Try common response shapes
          const candidates = [
            data.pages, data.images, data.data?.pages, data.data?.images,
            data.chapter?.pages, Array.isArray(data) ? data : null,
          ].filter(Boolean);

          for (const arr of candidates) {
            if (!Array.isArray(arr)) continue;
            for (const item of arr) {
              const urlStr = typeof item === "string" ? item :
                item?.url || item?.imageUrl || item?.image_url || item?.src || item?.path;
              if (typeof urlStr === "string") {
                const abs = toAbs(urlStr, base);
                if (abs && IMG_EXT.test(abs) && isMangaPage(abs)) urls.push(abs);
              }
            }
            if (urls.length > 0) return dedupe(urls);
          }
        }
      } catch { }
    }
  } catch { }
  return urls;
}

function extractHtmlImgs($: cheerio.CheerioAPI, base: string): string[] {
  const urls: string[] = [];
  const containers = [
    "#readerarea", ".reading-content", "#chapter-images",
    ".chapter-images", ".manga-reader", ".comic-content",
    ".voldata", ".imgs_page", ".reader-area", ".viewer",
    "article", "#content-manga", ".chapter-reader", ".reader",
    "[class*='reader']", "[class*='chapter']", "[id*='reader']",
  ];

  for (const sel of containers) {
    const found: string[] = [];
    $(`${sel} img`).each((_i, el) => {
      const raw = $(el).attr("data-src") || $(el).attr("data-lazy-src") || $(el).attr("data-original") || $(el).attr("data-cfsrc") || $(el).attr("src") || "";
      const abs = toAbs(raw, base);
      if (abs && isMangaPage(abs)) found.push(abs);
    });
    if (found.length > 0) { urls.push(...found); break; }
  }
  return urls;
}

function extractAllImgs($: cheerio.CheerioAPI, base: string): string[] {
  const urls: string[] = [];
  $("img").each((_i, el) => {
    const raw = $(el).attr("data-src") || $(el).attr("data-lazy-src") || $(el).attr("data-original") || $(el).attr("src") || "";
    const abs = toAbs(raw, base);
    if (abs && IMG_EXT.test(abs) && isMangaPage(abs)) urls.push(abs);
  });
  return urls;
}

// ─────────────────────────────────────────────
// SCORE & SELECT BEST CANDIDATE SET
// ─────────────────────────────────────────────

function scoreCandidates(candidates: string[][]): string[] {
  const scored = candidates
    .filter(c => c.length > 0)
    .map(list => {
      const deduped = dedupe(list);
      const domains = deduped.map(u => { try { const x = new URL(u); return x.hostname + x.pathname.split("/").slice(0, -1).join("/"); } catch { return ""; } });
      const domainCounts: Record<string, number> = {};
      domains.forEach(d => { domainCounts[d] = (domainCounts[d] ?? 0) + 1; });
      const maxGroup = Math.max(...Object.values(domainCounts));
      return { list: deduped, score: maxGroup };
    });

  if (!scored.length) return [];
  scored.sort((a, b) => b.score - a.score);
  return scored[0].list;
}

// ─────────────────────────────────────────────
// CLOUDFLARE BYPASS — retry with varied headers
// ─────────────────────────────────────────────

async function fetchWithCloudflareBypass(url: string): Promise<string> {
  // First attempt — standard browser headers
  const attempts = [
    buildHeaders(url),
    // Second attempt — slightly different UA + no sec-fetch-user
    {
      "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
      "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.5",
      "Accept-Encoding": "gzip, deflate, br",
      "Referer": getOrigin(url) + "/",
      "Connection": "keep-alive",
      "Upgrade-Insecure-Requests": "1",
    },
  ];

  let lastError: unknown;
  for (const headers of attempts) {
    try {
      const res = await axios.get(url, {
        headers,
        timeout: 45000,
        maxRedirects: 10,
        responseType: "text",
        // Allow 403 to fall through to next attempt without throwing immediately
        validateStatus: (s) => s < 500,
      });
      if (res.status === 200) return res.data as string;
      if (res.status === 403) {
        lastError = new Error(`الموقع محمي بـ Cloudflare (403) — لا يمكن الاستيراد منه تلقائياً`);
        continue;
      }
      throw new Error(`HTTP ${res.status}`);
    } catch (err) {
      lastError = err;
    }
  }
  throw lastError;
}

// ─────────────────────────────────────────────
// MAIN FETCH FUNCTION
// ─────────────────────────────────────────────

async function fetchPageUrls(url: string): Promise<{
  title: string;
  pageUrls: string[];
  chapterNumber: number | null;
  mangaTitle: string | null;
}> {
  const html = await fetchWithCloudflareBypass(url);
  const $ = cheerio.load(html);

  const scripts: string[] = [];
  $("script").each((_i, el) => {
    const t = $(el).html() ?? "";
    if (t.length > 10) scripts.push(t);
  });

  const candidates: string[][] = [];

  // A: ts_reader (highest priority)
  const tsResult = extractTsReader(html, url);
  if (tsResult.length) candidates.push(tsResult);

  // B: JSON blobs in scripts
  const jsonResult = extractFromJsonBlobs(scripts, url);
  if (jsonResult.length) candidates.push(jsonResult);

  // C: JS variable arrays
  const jsArrayResult = extractJsArrays(scripts, url);
  if (jsArrayResult.length) candidates.push(jsArrayResult);

  // D: HTML containers
  if (!candidates.some(c => c.length > 2)) {
    const htmlResult = extractHtmlImgs($, url);
    if (htmlResult.length) candidates.push(htmlResult);
  }

  // E: Broad fallback
  if (!candidates.some(c => c.length > 2)) {
    const allImgs = extractAllImgs($, url);
    if (allImgs.length) candidates.push(allImgs);
  }

  // F: Astro nanostores inline serialized data
  if (!candidates.some(c => c.length > 2)) {
    const astroResult = extractAstroNanostores(html, url);
    if (astroResult.length) candidates.push(astroResult);
  }

  // G: _vcomics / azorafly-style API (async, only if nothing else worked)
  if (!candidates.some(c => c.length > 2)) {
    const vcomicsResult = await extractVcomicsApi(html, url);
    if (vcomicsResult.length) candidates.push(vcomicsResult);
  }

  const pageUrls = scoreCandidates(candidates);

  // ── Metadata ──
  const title = $("title").text().trim() || $("h1").first().text().trim() || "فصل غير محدد";

  let mangaTitle: string | null = null;
  const breadcrumbs = $(".breadcrumb a, .breadcrumbs a, nav a").toArray();
  if (breadcrumbs.length >= 2) mangaTitle = $(breadcrumbs[breadcrumbs.length - 2]).text().trim() || null;
  if (!mangaTitle) mangaTitle = $(".post-title h1, .manga-title, h1.entry-title").first().text().trim() || null;
  // Also try Astro nanostores seriesTitle
  if (!mangaTitle) {
    const seriesTitleMatch = html.match(/"seriesTitle"\s*:\s*\[\s*0\s*,\s*"([^"]+)"/);
    if (seriesTitleMatch) mangaTitle = seriesTitleMatch[1];
  }

  let chapterNumber: number | null = null;
  // Try Astro nanostores chapterNumber
  const astroChNum = html.match(/"chapterNumber"\s*:\s*\[\s*0\s*,\s*([\d.]+)\s*\]/);
  if (astroChNum) chapterNumber = parseFloat(astroChNum[1]);
  else {
    const urlChapterMatch = url.match(/\/(\d+(?:\.\d+)?)\/?(?:\?.*)?$/);
    if (urlChapterMatch) chapterNumber = parseFloat(urlChapterMatch[1]);
    else {
      const m = title.match(/chapter\s*([\d.]+)|فصل\s*([\d.]+)/i);
      if (m) chapterNumber = parseFloat(m[1] || m[2]);
    }
  }

  return { title, pageUrls, chapterNumber, mangaTitle };
}

// ─────────────────────────────────────────────
// ROUTES
// ─────────────────────────────────────────────

const router: IRouter = Router();

router.post("/remote/preview", requirePublisher, async (req, res): Promise<void> => {
  const parsed = RemotePreviewBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  try {
    const { title, pageUrls, chapterNumber, mangaTitle } = await fetchPageUrls(parsed.data.url);
    res.json({ title, pageCount: pageUrls.length, pageUrls, chapterNumber, mangaTitle });
  } catch (error: any) {
    req.log.error({ err: error }, "remote preview failed");
    res.status(400).json({ error: `فشل في جلب الصفحات: ${error.message}` });
  }
});

router.post("/remote/import", requirePublisher, async (req, res): Promise<void> => {
  const parsed = RemoteImportBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { url, chapterId } = parsed.data;

  try {
    const { pageUrls } = await fetchPageUrls(url);

    if (pageUrls.length === 0) {
      res.status(400).json({ success: false, importedPages: 0, message: "لم يتم العثور على صور الفصل في هذا الرابط", errors: [] });
      return;
    }

    const [maxPage] = await db
      .select({ max: sql<number>`COALESCE(MAX(page_number), 0)` })
      .from(pagesTable)
      .where(eq(pagesTable.chapterId, chapterId));

    const startPageNumber = Number(maxPage?.max ?? 0) + 1;
    let importedPages = 0;
    const errors: string[] = [];

    for (let i = 0; i < pageUrls.length; i++) {
      const imageUrl = pageUrls[i];
      const ext = imageUrl.match(/\.(jpe?g|png|webp|gif|avif)/i)?.[0] ?? ".jpg";
      const filename = `remote-${Date.now()}-${i}${ext}`;
      const storedUrl = await storeRemoteImage(imageUrl, filename, url);
      if (storedUrl) {
        await db.insert(pagesTable).values({ chapterId, pageNumber: startPageNumber + i, imageUrl: storedUrl });
        importedPages++;
      } else {
        errors.push(`فشل تحميل الصفحة ${i + 1}`);
      }
    }

    res.json({
      success: importedPages > 0,
      importedPages,
      message: importedPages > 0
        ? `تم استيراد ${importedPages} صفحة بنجاح` + (errors.length ? ` (${errors.length} فشلت)` : "")
        : "فشل استيراد جميع الصفحات",
      errors,
    });
  } catch (error: any) {
    req.log.error({ err: error }, "remote import failed");
    res.status(400).json({ success: false, importedPages: 0, message: `خطأ: ${error.message}`, errors: [] });
  }
});

export default router;
