import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { 
  usePublisherAuth, 
  useCreateManga, 
  useCreateChapter, 
  useListPendingChapters,
  useListManga,
  usePublishChapter,
  useDeleteChapter,
  useDeletePage,
  useRemoteImport,
  useListChapters,
  useListPages,
  getListChaptersQueryKey,
  getListPagesQueryKey
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Checkbox } from "@/components/ui/checkbox";

export default function Publisher() {
  const { publisherToken, setPublisherToken } = useAuth();
  const [code, setCode] = useState("");
  const auth = usePublisherAuth();
  const { toast } = useToast();

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    auth.mutate(
      { data: { code } },
      {
        onSuccess: (res) => {
          if (res.success && res.token) {
            setPublisherToken(res.token);
            toast({ title: "تم الدخول كـ ناشر" });
          } else {
            toast({ variant: "destructive", title: "الرمز غير صحيح" });
          }
        }
      }
    );
  };

  if (!publisherToken) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <form onSubmit={handleAuth} className="w-full max-w-sm space-y-4">
          <Label>أدخل رمز الناشر</Label>
          <Input 
            type="password"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="text-center font-mono"
            required
          />
          <Button type="submit" className="w-full" disabled={auth.isPending}>
            دخول
          </Button>
        </form>
      </div>
    );
  }

  return (
    <div className="container py-8 max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">لوحة تحكم الناشر</h1>
        <Button variant="outline" onClick={() => setPublisherToken(null)}>
          الخروج من لوحة الناشر
        </Button>
      </div>

      <Tabs defaultValue="remote" className="w-full">
        <TabsList className="grid w-full grid-cols-4 h-auto">
          <TabsTrigger value="remote" className="py-3">📥 استيراد بعيد</TabsTrigger>
          <TabsTrigger value="add-chapter" className="py-3">➕ رفع يدوي</TabsTrigger>
          <TabsTrigger value="pending" className="py-3">⏳ الفصول المعلقة</TabsTrigger>
          <TabsTrigger value="create-manga" className="py-3">📚 إنشاء مانغا</TabsTrigger>
        </TabsList>
        
        <div className="mt-6 bg-card border border-border rounded-xl p-6 shadow-sm">
          <TabsContent value="remote">
            <RemoteImportForm token={publisherToken} />
          </TabsContent>
          <TabsContent value="add-chapter">
            <AddChapterForm token={publisherToken} />
          </TabsContent>
          <TabsContent value="pending">
            <PendingChapters token={publisherToken} />
          </TabsContent>
          <TabsContent value="create-manga">
            <CreateMangaForm token={publisherToken} />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}

const GENRES = [
  "أكشن", "مغامرة", "كوميديا", "دراما", "خيال", "رومانسية", "خيال علمي", "شريحة من الحياة", "رياضة", "رعب", "غموض", "نفسي", "تاريخي", "فنون قتالية"
];

function CreateMangaForm({ token }: { token: string }) {
  const createManga = useCreateManga({ request: { headers: { Authorization: `Bearer ${token}` } } });
  const { toast } = useToast();
  
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [coverImage, setCoverImage] = useState("");
  const [type, setType] = useState("manhwa");
  const [status, setStatus] = useState("ongoing");
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [coverFile, setCoverFile] = useState<File | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    let finalCoverUrl = coverImage;

    if (coverFile) {
      const formData = new FormData();
      formData.append("cover", coverFile);
      try {
        const res = await fetch("/api/uploads/cover", {
          method: "POST",
          headers: { Authorization: `Bearer ${token}` },
          body: formData
        });
        const data = await res.json();
        if (data.url) finalCoverUrl = data.url;
      } catch {
        toast({ variant: "destructive", title: "فشل رفع الغلاف" });
        return;
      }
    }

    createManga.mutate({
      data: { title, description, coverImage: finalCoverUrl, type, status, genres: selectedGenres }
    }, {
      onSuccess: () => {
        toast({ title: "تم إنشاء العمل بنجاح" });
        setTitle(""); setDescription(""); setCoverImage(""); setCoverFile(null); setSelectedGenres([]);
      }
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label>العنوان</Label>
        <Input required value={title} onChange={e => setTitle(e.target.value)} />
      </div>
      <div className="space-y-2">
        <Label>الوصف</Label>
        <Textarea rows={4} value={description} onChange={e => setDescription(e.target.value)} />
      </div>
      
      <div className="grid grid-cols-2 gap-4 border p-4 rounded-lg bg-secondary/10">
        <div className="space-y-2">
          <Label>رابط صورة الغلاف</Label>
          <Input value={coverImage} onChange={e => setCoverImage(e.target.value)} placeholder="https://..." disabled={!!coverFile} />
        </div>
        <div className="space-y-2">
          <Label>أو رفع صورة</Label>
          <Input type="file" accept="image/*" onChange={e => setCoverFile(e.target.files?.[0] || null)} disabled={!!coverImage} />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>النوع</Label>
          <Select value={type} onValueChange={setType}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="manhwa">مانهوا</SelectItem>
              <SelectItem value="manga">مانغا</SelectItem>
              <SelectItem value="manhua">مانهوا صينية</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>الحالة</Label>
          <Select value={status} onValueChange={setStatus}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ongoing">مستمر</SelectItem>
              <SelectItem value="completed">مكتمل</SelectItem>
              <SelectItem value="dropped">متوقف</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label>التصنيفات</Label>
        <div className="grid grid-cols-3 md:grid-cols-5 gap-3 p-4 border rounded-lg bg-secondary/5">
          {GENRES.map(g => (
            <div key={g} className="flex items-center space-x-2 space-x-reverse">
              <Checkbox 
                id={`genre-${g}`} 
                checked={selectedGenres.includes(g)}
                onCheckedChange={(checked) => {
                  if (checked) setSelectedGenres([...selectedGenres, g]);
                  else setSelectedGenres(selectedGenres.filter(x => x !== g));
                }}
              />
              <Label htmlFor={`genre-${g}`} className="text-sm cursor-pointer">{g}</Label>
            </div>
          ))}
        </div>
      </div>

      <Button type="submit" disabled={createManga.isPending} className="w-full">
        {createManga.isPending ? "جاري الإنشاء..." : "إنشاء العمل"}
      </Button>
    </form>
  );
}

function AddChapterForm({ token }: { token: string }) {
  const { data: mangaList } = useListManga({ limit: 100 });
  const createChapter = useCreateChapter({ request: { headers: { Authorization: `Bearer ${token}` } } });
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [mangaId, setMangaId] = useState("");
  const [number, setNumber] = useState("");
  const [title, setTitle] = useState("");
  const [files, setFiles] = useState<FileList | null>(null);
  const [uploading, setUploading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mangaId || !number || !files || files.length === 0) return;
    try {
      setUploading(true);
      const chapter = await createChapter.mutateAsync({
        mangaId: Number(mangaId),
        data: { number: Number(number), title: title || undefined }
      });

      const formData = new FormData();
      Array.from(files).forEach(f => formData.append("pages", f));

      const uploadRes = await fetch(`/api/manga/${mangaId}/chapters/${chapter.id}/pages/upload`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: formData
      });

      if (!uploadRes.ok) throw new Error("فشل رفع الصفحات");
      toast({ title: "تم إنشاء الفصل ورفع الصفحات، بانتظار النشر." });
      setNumber(""); setTitle(""); setFiles(null);
      queryClient.invalidateQueries({ queryKey: ["/api/publisher/pending-chapters"] });
    } catch {
      toast({ variant: "destructive", title: "حدث خطأ أثناء الرفع" });
    } finally {
      setUploading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label>اختر العمل</Label>
        <Select value={mangaId} onValueChange={setMangaId}>
          <SelectTrigger><SelectValue placeholder="اختر المانغا" /></SelectTrigger>
          <SelectContent>
            {mangaList?.data.map(m => (
              <SelectItem key={m.id} value={m.id.toString()}>{m.title}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>رقم الفصل</Label>
          <Input type="number" step="0.1" required value={number} onChange={e => setNumber(e.target.value)} />
        </div>
        <div className="space-y-2">
          <Label>عنوان الفصل (اختياري)</Label>
          <Input value={title} onChange={e => setTitle(e.target.value)} />
        </div>
      </div>

      <div className="space-y-2">
        <Label>صفحات الفصل</Label>
        <div className="border-2 border-dashed rounded-lg p-8 text-center bg-secondary/10 hover:bg-secondary/20 transition-colors">
          <Input type="file" multiple accept="image/*" className="hidden" id="pages-upload" onChange={e => setFiles(e.target.files)} />
          <Label htmlFor="pages-upload" className="cursor-pointer flex flex-col items-center justify-center gap-2">
            <span className="text-primary font-bold">اختر الصور</span>
            <span className="text-xs text-muted-foreground">
              {files ? `تم اختيار ${files.length} صورة` : "يمكنك اختيار عدة صور معاً"}
            </span>
          </Label>
        </div>
      </div>

      <Button type="submit" disabled={uploading || !mangaId || !files} className="w-full">
        {uploading ? "جاري الرفع..." : "إنشاء ورفع"}
      </Button>
    </form>
  );
}

type RemoteStep = "form" | "downloading" | "review";

function RemoteImportForm({ token }: { token: string }) {
  const { data: mangaList } = useListManga({ limit: 100 });
  const [mangaId, setMangaId]     = useState("");
  const [chapNum, setChapNum]     = useState("");
  const [chapTitle, setChapTitle] = useState("");
  const [url, setUrl]             = useState("");
  const [step, setStep]           = useState<RemoteStep>("form");
  const [log, setLog]             = useState("");
  const [importedMangaId, setImportedMangaId]     = useState<number | null>(null);
  const [importedChapterId, setImportedChapterId] = useState<number | null>(null);

  const createChapter  = useCreateChapter ({ request: { headers: { Authorization: `Bearer ${token}` } } });
  const importRemote   = useRemoteImport  ({ request: { headers: { Authorization: `Bearer ${token}` } } });
  const publishChapter = usePublishChapter({ request: { headers: { Authorization: `Bearer ${token}` } } });
  const deleteChapter  = useDeleteChapter ({ request: { headers: { Authorization: `Bearer ${token}` } } });
  const deletePage     = useDeletePage    ({ request: { headers: { Authorization: `Bearer ${token}` } } });
  const queryClient    = useQueryClient();
  const { toast }      = useToast();

  const { data: pages, isLoading: pagesLoading, refetch: refetchPages } = useListPages(
    importedMangaId  ?? 0,
    importedChapterId ?? 0,
    {
      query: {
        enabled: !!importedMangaId && !!importedChapterId,
        queryKey: getListPagesQueryKey(importedMangaId ?? 0, importedChapterId ?? 0)
      },
      request: { headers: { Authorization: `Bearer ${token}` } }
    }
  );

  const sortedPages = [...(pages ?? [])].sort((a, b) => a.pageNumber - b.pageNumber);

  const resetForm = () => {
    setStep("form");
    setImportedChapterId(null);
    setImportedMangaId(null);
    setUrl(""); setChapNum(""); setChapTitle(""); setMangaId(""); setLog("");
  };

  const handleDownload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mangaId || !chapNum || !url) return;
    setStep("downloading");
    setLog("⏳ جاري إنشاء الفصل...");

    let chapterId: number;
    try {
      const chapter = await createChapter.mutateAsync({
        mangaId: Number(mangaId),
        data: { number: Number(chapNum), title: chapTitle || undefined }
      });
      chapterId = chapter.id;
      setLog("✅ تم إنشاء الفصل. ⏳ جاري تنزيل الصفحات من الرابط...");
    } catch {
      setLog("❌ فشل إنشاء الفصل.");
      toast({ variant: "destructive", title: "فشل إنشاء الفصل" });
      setStep("form");
      return;
    }

    try {
      const result = await importRemote.mutateAsync({
        data: { url, mangaId: Number(mangaId), chapterId }
      });

      if (!result.success || result.importedPages === 0) {
        setLog(`❌ لم يتم العثور على صفحات. جاري حذف الفصل الفارغ...`);
        await deleteChapter.mutateAsync({ mangaId: Number(mangaId), chapterId });
        toast({ variant: "destructive", title: "لم يتم العثور على صفحات", description: "تأكد أن الرابط هو رابط فصل مباشر" });
        setStep("form");
        return;
      }

      setImportedMangaId(Number(mangaId));
      setImportedChapterId(chapterId);
      setLog(`✅ تم تنزيل ${result.importedPages} صفحة بنجاح!`);
      await queryClient.invalidateQueries({ queryKey: getListPagesQueryKey(Number(mangaId), chapterId) });
      setStep("review");

    } catch (err: any) {
      setLog(`❌ خطأ: ${err?.message ?? "خطأ غير معروف"}`);
      toast({ variant: "destructive", title: "فشل الاستيراد", description: err?.message });
      try { await deleteChapter.mutateAsync({ mangaId: Number(mangaId), chapterId }); } catch {}
      setStep("form");
    }
  };

  const handlePublish = () => {
    if (!importedMangaId || !importedChapterId) return;
    publishChapter.mutate({ mangaId: importedMangaId, chapterId: importedChapterId }, {
      onSuccess: () => {
        toast({ title: "✅ تم نشر الفصل بنجاح" });
        queryClient.invalidateQueries({ queryKey: ["/api/publisher/pending-chapters"] });
        resetForm();
      },
      onError: () => toast({ variant: "destructive", title: "فشل النشر" })
    });
  };

  const handleDeleteChapter = () => {
    if (!importedMangaId || !importedChapterId) return;
    if (!confirm("هل أنت متأكد من حذف الفصل كاملاً مع صفحاته؟")) return;
    deleteChapter.mutate({ mangaId: importedMangaId, chapterId: importedChapterId }, {
      onSuccess: () => { toast({ title: "تم حذف الفصل" }); resetForm(); },
      onError: () => toast({ variant: "destructive", title: "فشل الحذف" })
    });
  };

  const handleDeletePage = (pageId: number) => {
    if (!importedMangaId || !importedChapterId) return;
    if (!confirm("حذف هذه الصفحة؟")) return;
    deletePage.mutate({ mangaId: importedMangaId, chapterId: importedChapterId, pageId }, {
      onSuccess: () => {
        toast({ title: "تم حذف الصفحة" });
        refetchPages();
      },
      onError: () => toast({ variant: "destructive", title: "فشل حذف الصفحة" })
    });
  };

  if (step === "downloading") {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-6 text-center">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
        <p className="text-lg font-medium">{log || "جاري التنزيل..."}</p>
        <p className="text-sm text-muted-foreground">قد يستغرق هذا حتى دقيقة، لا تغلق الصفحة</p>
      </div>
    );
  }

  if (step === "review" && importedChapterId && importedMangaId) {
    return (
      <div className="space-y-5">
        {/* Status bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 p-4 bg-green-950/30 border border-green-800/40 rounded-xl">
          <div>
            <p className="font-bold text-green-400">{log}</p>
            <p className="text-sm text-muted-foreground mt-0.5">
              {pagesLoading ? "جاري تحميل الصفحات..." : `${sortedPages.length} صفحة جاهزة`}
            </p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button variant="outline" size="sm" onClick={resetForm}>
              ← استيراد جديد
            </Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={handleDeleteChapter}
              disabled={deleteChapter.isPending}
            >
              🗑 حذف الفصل
            </Button>
            <Button
              size="sm"
              className="bg-green-600 hover:bg-green-700 text-white"
              onClick={handlePublish}
              disabled={publishChapter.isPending || sortedPages.length === 0}
            >
              {publishChapter.isPending ? "جاري النشر..." : "✓ نشر الفصل"}
            </Button>
          </div>
        </div>

        {/* Pages grid */}
        {pagesLoading ? (
          <div className="flex items-center justify-center py-12 gap-3">
            <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            <span>جاري تحميل الصور...</span>
          </div>
        ) : sortedPages.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground border rounded-xl bg-secondary/5">
            لا توجد صفحات
          </div>
        ) : (
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
            {sortedPages.map((page, idx) => (
              <div
                key={page.id}
                className="group relative bg-secondary rounded-lg overflow-hidden"
                style={{ aspectRatio: "2/3" }}
              >
                <img
                  src={page.imageUrl}
                  className="w-full h-full object-cover"
                  alt={`صفحة ${idx + 1}`}
                  loading="lazy"
                />
                {/* Page number */}
                <div className="absolute bottom-1 right-1 bg-black/70 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
                  {idx + 1}
                </div>
                {/* Delete on hover */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <button
                    type="button"
                    onClick={() => handleDeletePage(page.id)}
                    className="w-9 h-9 rounded-full bg-red-600 hover:bg-red-700 text-white text-xl flex items-center justify-center shadow-lg transition-colors"
                    title="حذف الصفحة"
                  >
                    ×
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  // Step: form
  return (
    <form onSubmit={handleDownload} className="space-y-6">
      <div className="p-4 bg-blue-950/20 border border-blue-800/30 rounded-xl text-sm text-blue-300 leading-relaxed">
        <strong>كيف يعمل؟</strong> أدخل بيانات الفصل ورابطه ← اضغط "تنزيل" ← ستظهر الصور فوراً ← راجعها واحذف ما لا تريده ← اضغط "نشر".
      </div>

      <div className="space-y-2">
        <Label>العمل (المانغا) *</Label>
        <Select value={mangaId} onValueChange={setMangaId} required>
          <SelectTrigger><SelectValue placeholder="اختر المانغا" /></SelectTrigger>
          <SelectContent>
            {mangaList?.data.map(m => (
              <SelectItem key={m.id} value={m.id.toString()}>{m.title}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>رقم الفصل *</Label>
          <Input
            type="number"
            step="0.1"
            min="0"
            required
            value={chapNum}
            onChange={e => setChapNum(e.target.value)}
            placeholder="مثال: 1"
          />
        </div>
        <div className="space-y-2">
          <Label>عنوان الفصل (اختياري)</Label>
          <Input value={chapTitle} onChange={e => setChapTitle(e.target.value)} placeholder="اختياري" />
        </div>
      </div>

      <div className="space-y-2">
        <Label>رابط الفصل *</Label>
        <Input
          type="url"
          required
          value={url}
          onChange={e => setUrl(e.target.value)}
          placeholder="https://mangalek.com/..."
          dir="ltr"
          className="font-mono text-sm"
        />
        <p className="text-xs text-muted-foreground">ضع رابط صفحة الفصل مباشرةً (وليس الصفحة الرئيسية للمانغا)</p>
      </div>

      <Button
        type="submit"
        className="w-full h-12 text-base"
        disabled={!mangaId || !chapNum || !url}
      >
        📥 تنزيل وإنشاء الفصل
      </Button>
    </form>
  );
}

function PendingChapters({ token }: { token: string }) {
  const { data: pending, isLoading } = useListPendingChapters({
    request: { headers: { Authorization: `Bearer ${token}` } }
  });
  const publishChapter = usePublishChapter({ request: { headers: { Authorization: `Bearer ${token}` } } });
  const deleteChapter  = useDeleteChapter ({ request: { headers: { Authorization: `Bearer ${token}` } } });
  const queryClient    = useQueryClient();
  const { toast }      = useToast();

  const handlePublish = (mangaId: number, chapterId: number) => {
    publishChapter.mutate({ mangaId, chapterId }, {
      onSuccess: () => {
        toast({ title: "✅ تم النشر بنجاح" });
        queryClient.invalidateQueries({ queryKey: ["/api/publisher/pending-chapters"] });
      },
      onError: () => toast({ variant: "destructive", title: "فشل النشر" })
    });
  };

  const handleDelete = (mangaId: number, chapterId: number) => {
    if (!confirm("هل أنت متأكد من حذف الفصل؟")) return;
    deleteChapter.mutate({ mangaId, chapterId }, {
      onSuccess: () => {
        toast({ title: "تم الحذف" });
        queryClient.invalidateQueries({ queryKey: ["/api/publisher/pending-chapters"] });
      },
      onError: () => toast({ variant: "destructive", title: "فشل الحذف" })
    });
  };

  if (isLoading) return <div className="text-center py-12">جاري التحميل...</div>;
  if (!pending?.length) return (
    <div className="text-center py-16 text-muted-foreground border rounded-xl bg-secondary/5 space-y-2">
      <p className="text-2xl">✅</p>
      <p>لا توجد فصول معلقة</p>
    </div>
  );

  return (
    <div className="space-y-6">
      {pending.map(chapter => (
        <PendingChapterCard
          key={chapter.id}
          chapter={chapter}
          token={token}
          onPublish={handlePublish}
          onDelete={handleDelete}
        />
      ))}
    </div>
  );
}

function PendingChapterCard({
  chapter,
  token,
  onPublish,
  onDelete,
}: {
  chapter: { id: number; mangaId: number; number: number; title?: string | null; pageCount?: number | null; manga?: { title?: string | null } | null };
  token: string;
  onPublish: (mangaId: number, chapterId: number) => void;
  onDelete: (mangaId: number, chapterId: number) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const deletePage  = useDeletePage({ request: { headers: { Authorization: `Bearer ${token}` } } });
  const queryClient = useQueryClient();
  const { toast }   = useToast();

  const { data: pages, isLoading, refetch } = useListPages(chapter.mangaId, chapter.id, {
    query: {
      enabled: expanded,
      queryKey: getListPagesQueryKey(chapter.mangaId, chapter.id)
    },
    request: { headers: { Authorization: `Bearer ${token}` } }
  });

  const sortedPages = [...(pages ?? [])].sort((a, b) => a.pageNumber - b.pageNumber);

  const handleDeletePage = (pageId: number) => {
    if (!confirm("حذف هذه الصفحة؟")) return;
    deletePage.mutate({ mangaId: chapter.mangaId, chapterId: chapter.id, pageId }, {
      onSuccess: () => {
        toast({ title: "تم حذف الصفحة" });
        refetch();
        queryClient.invalidateQueries({ queryKey: getListPagesQueryKey(chapter.mangaId, chapter.id) });
      },
      onError: () => toast({ variant: "destructive", title: "فشل الحذف" })
    });
  };

  return (
    <div className="border border-border rounded-xl overflow-hidden bg-background shadow-sm">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-secondary/10">
        <div>
          <h3 className="font-bold text-lg">{chapter.manga?.title ?? ""} — فصل {chapter.number}</h3>
          <p className="text-sm text-muted-foreground">{chapter.pageCount ?? 0} صفحة</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button
            size="sm"
            variant="ghost"
            className="border border-border"
            onClick={() => setExpanded(v => !v)}
          >
            {expanded ? "إخفاء الصفحات ▲" : "عرض الصفحات ▼"}
          </Button>
          <Button size="sm" variant="destructive" onClick={() => onDelete(chapter.mangaId, chapter.id)}>
            🗑 حذف
          </Button>
          <Button
            size="sm"
            className="bg-green-600 hover:bg-green-700 text-white"
            onClick={() => onPublish(chapter.mangaId, chapter.id)}
          >
            ✓ نشر
          </Button>
        </div>
      </div>

      {/* Pages grid (collapsible) */}
      {expanded && (
        <div className="p-4 border-t border-border">
          {isLoading ? (
            <div className="flex items-center justify-center py-8 gap-2 text-muted-foreground">
              <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              جاري التحميل...
            </div>
          ) : sortedPages.length === 0 ? (
            <p className="text-center py-6 text-muted-foreground">لا توجد صفحات</p>
          ) : (
            <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2">
              {sortedPages.map((page, idx) => (
                <div
                  key={page.id}
                  className="group relative bg-secondary rounded overflow-hidden"
                  style={{ aspectRatio: "2/3" }}
                >
                  <img src={page.imageUrl} className="w-full h-full object-cover" alt={`${idx + 1}`} loading="lazy" />
                  <div className="absolute bottom-0.5 right-0.5 bg-black/70 text-white text-[9px] px-1 rounded">
                    {idx + 1}
                  </div>
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <button
                      type="button"
                      onClick={() => handleDeletePage(page.id)}
                      className="w-7 h-7 rounded-full bg-red-600 hover:bg-red-700 text-white text-base flex items-center justify-center"
                    >
                      ×
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
